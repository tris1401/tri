
import java.rmi.*;
import java.rmi.server.* ;
import java.rmi.registry.*;
import java.util.*;
public class HotelServer extends RoomManagerImpl{
	public HotelServer()throws RemoteException{
		
	}
	public static void main(String[]args){
		try{
			int index=0;
			int port=Integer.parseInt(args[index++]);
			
			RoomManagerImpl obj=new RoomManagerImpl();
			RoomManager skeleton=(RoomManager)UnicastRemoteObject.exportObject(obj,0);
			
			Registry registry=LocateRegistry.getRegistry(port);
			registry.rebind("Room",skeleton);
		}
		catch(Exception e){
			System.out.println(e.toString());
		}
	}
}
