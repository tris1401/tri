import java.rmi.*;
import java.rmi.server.* ;
import java.rmi.registry.*;
import java.util.*;

public class RoomManagerImpl implements RoomManager{
	private ArrayList<Employee> employees=new ArrayList<>();
	private ArrayList<Room> listrooms=new ArrayList<>();
		private ArrayList<String>listguest=new ArrayList<>();
	private Employee currentAccount;
	public RoomManagerImpl(){
		employees.add(new Employee("vodangtri","12345",1));//admin
		employees.add(new Employee("nguyenvana","12345",2));//nhanvien
		for(int i=1;i<=40;i++){
			if(i<=10){
				listrooms.add(new Room(i,"0",55));
			}  
			else if(i>10&& i<=30){
				listrooms.add(new Room(i,"1",75));
			}
			else if(i>30&& i<=35){
				listrooms.add(new Room(i,"2",80));
			}
			else if(i>35&& i<=38){
				listrooms.add(new Room(i,"3",150));	
			}
			else if(i>38&& i<=40){
				listrooms.add(new Room(i,"4",230));	
			}
		}
	}

	public void help() throws RemoteException{
		System.out.println("Huong dan su dung");
	}
	public String login(String username,String password) throws RemoteException{
		boolean checkLogin=false;
		for(Employee e:employees){
			if(e.getUsername().equals(username)&&e.getPassword().equals(password)){
				// System.out.println("Dang nhap thanh cong");  
				currentAccount=e;
				checkLogin=true;
                return "Dang nhap thanh cong";
			}
		}
		return "Dang nhap khong thanh cong";
		
	}
	public void logout() throws RemoteException{
		System.exit(1);
	}
public ArrayList<String> rooms() throws RemoteException {
    int t0 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0;
    int pr0 = 0, pr1 = 0, pr2 = 0, pr3 = 0, pr4 = 0, pr5 = 0;
    ArrayList<String> ds = new ArrayList<>();

    for (Room room : listrooms) {
        if (room.getType() == "0") {
            pr0 = room.getPrice();
            if (room.getGuest() == null) {
                t0++;
            }
        } else if (room.getType().equalsIgnoreCase("1")) {
            pr1 = room.getPrice();
            if (room.getGuest() == null) {
                t1++;
            }
        } else if (room.getType().equalsIgnoreCase("2")) {
            pr2 = room.getPrice();
            if (room.getGuest() == null) {
                t2++;
            }
        } else if (room.getType().equalsIgnoreCase("3")) {
            pr3 = room.getPrice();
            if (room.getGuest() == null) {
                t3++;
            }
        } else if (room.getType().equalsIgnoreCase("4")) {
            pr4 = room.getPrice();
            if (room.getGuest() == null) {
                t4++;
            }
        }
    }

    ds.add(t0 + " room of type 0 are available for " + pr0 + " Euros per night");
    ds.add(t1 + " room of type 1 are available for " + pr1 + " Euros per night");
    ds.add(t2 + " room of type 2 are available for " + pr2 + " Euros per night");
    ds.add(t3 + " room of type 3 are available for " + pr3 + " Euros per night");
    ds.add(t4 + " room of type 4 are available for " + pr4 + " Euros per night");

    return ds;
}
	
    public String bookRoom(String type,String guestname,String guestssn) throws RemoteException{

		for(Room room:listrooms){
			if(room.getType().equalsIgnoreCase(type)){
				if(room.isAvailable()!=-1){
					room.setGuest(new Guest(guestname,guestssn));
					listguest.add(room.getGuest().getName()+"," +room.getGuest().getSSN()+","+room.getType()+","+room.getPrice());
					// System.out.println("Dang ki thanh cong");
                    return "Dang ki thanh cong";
				}
			}
		}
		return "Dang ki khong thanh cong";
		
	}
	public ArrayList<String> guests() throws RemoteException{
		return listguest;
	}

	
}
