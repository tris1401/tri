import java.rmi.*;
import java.rmi.server.* ;
import java.rmi.registry.*;
import java.util.*;
public interface RoomManager extends Remote{
	public void help() throws RemoteException;
	public String login(String username,String password) throws RemoteException;
	public void logout() throws RemoteException;
	public ArrayList<String> rooms() throws RemoteException;
	public String bookRoom(String type,String guestname,String guestssn) throws RemoteException;
	public ArrayList<String>guests() throws RemoteException;
}