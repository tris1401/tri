public class Room{
	private int id;
	private String type;
	private int price;
	private Guest guest;
	
	public Room(int id,String type,int price){
		this.id=id;
		this.type=type;
		this.price=price;
		this.guest=null;
	}
	public String getType(){
		return this.type;
	}
	public int getPrice(){
		return this.price;
	}
	public Guest getGuest(){
		return this.guest;
	}
	public int isAvailable(){
		if(this.guest==null){
			return this.id;
		}
		return -1;
	}
	public void setGuest(Guest guest){
		this.guest=guest;
	}
	
}