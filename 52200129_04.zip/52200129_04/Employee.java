public class Employee{
	private String username;
	private String password;
	private int role;
	
	public Employee(String username,String password,int role){
		this.username=username;
		this.password=password;
		this.role=role;
	}
	public String getUsername(){
		return this.username;
	}
	public String getPassword(){
		return this.password;
	}
}