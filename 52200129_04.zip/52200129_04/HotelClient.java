import java.rmi.*;
import java.rmi.server.* ;
import java.rmi.registry.*;
import java.util.*;

public class HotelClient extends RoomManagerImpl{
	public HotelClient(){
		
	}
	public static void main(String args[]){
		try{
			String host="",action="",input1="",input2="",input3="";
			int port=0;
			if(args.length<2||args.length>7){
				System.exit(1);
			}
			int index=0;
			host=args[index++];
			port=Integer.parseInt(args[index++]);
			if(args.length==3){
				//int index=0;
				//host=args[index++];
				//port=Integer.parseInt(args[index++]);
				action=args[index++];
			}
			else if(args.length==5){

				action=args[index++];
				input1=args[index++];
				input2=args[index++];
			}
			else if(args.length==5){
				//int index=0;
				//host=args[index++];
				//port=Integer.parseInt(args[index++]);
				action=args[index++];
				input1=args[index++];
				input2=args[index++];
			}
			else if(args.length==6){
				//int index=0;
				//host=args[index++];
				//port=Integer.parseInt(args[index++]);
				action=args[index++];
				input1=args[index++];
				input2=args[index++];
				input3=args[index++];
			}
			
			Registry registry=LocateRegistry.getRegistry(host,port);
			RoomManager stub=(RoomManager)registry.lookup("Room");
														 
			if(args.length==2||(args.length==3&&action.equalsIgnoreCase("-help"))){
				stub.help();
			}
			else if(args.length==3&&action.equalsIgnoreCase("-list")){
				//System.out.println(stub.rooms());
				for(String room:stub.rooms()){
					System.out.println(room);
				}
				
			}
			else if(args.length==3&&action.equalsIgnoreCase("-guests")){
				System.out.println(stub.guests().size());
				for(String g:stub.guests()){
					System.out.println(g);
				}
				
			}
			else if(args.length==3&&action.equalsIgnoreCase("-logOut")){
				stub.logout();	
			}
			else if((args.length==6&&action.equalsIgnoreCase("-book"))||(args.length==5&&action.equalsIgnoreCase("-book"))){
				if(args.length==6){
					System.out.println(stub.bookRoom(input1,input2,input3));
				}
				if(args.length==5){
					String guestssn=UUID.randomUUID().toString();
					
					System.out.println(stub.bookRoom(input1,input2,guestssn));
				}
				
			
			}
			
			else if(args.length==5&&action.equalsIgnoreCase("-logIn")){
				System.out.println(stub.login(input1,input2));
				
			}
		}
		catch(Exception e){
			System.out.println(e.toString());
		}
	}
}