public class Guest{
	private String guestname;
	private String guestssn ;
	public Guest(String guestname,String guestssn){
		this.guestname=guestname;
		this.guestssn=guestssn;
	}
	public String getName(){
		return this.guestname;
	}
	public String getSSN(){
		return this.guestssn;
	}
}